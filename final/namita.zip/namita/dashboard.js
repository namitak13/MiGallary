$(document).ready(function () {
           
    $("#table1").DataTable();
    $(".table-area").hide();
    
    document.getElementById("loggedinUser").innerHTML = "<h3> Hey ," + sessionStorage.getItem("name") + "</h3>";

    $("#like").click(function(){
        let tableLike = "<thead><tr><td>User</td><td>Image Title</td><td>Time</td></tr></thead><tbody>";
        $.getJSON("http://localhost:3000/likes", function(result){
            $.each(result, function(i, field){
                if(field.imageowner === sessionStorage.getItem("name") && field.like === "true")
                {
                    tableLike+="<tr><td>" + field.lname + "</td><td>" + "<a href='../html/preview.html?id=" +
                    field.imageid + "&name=" + field.imageowner + "''>"+ field.imagename +
                     "</a></td><td>" + field.time + "</td></tr>";
                }
            });
            tableLike += "</tbody>"
            document.getElementById("table1").innerHTML = tableLike;
        });
        $(".table-area").show();
    });

  
    $("#comment").click(function(){
        let tableComment = "<thead><tr><td>Image Title</td><td>User</td><td>Comment</td><td>Time</td></tr></thead><tbody>";
            $.getJSON("http://localhost:3000/comment", function(result){
                $.each(result, function(i, field){
                    if(field.imageowner === sessionStorage.getItem("name"))
                    {
                        tableComment+="<tr><td>" + "<a href='../html/preview.html?id=" +
                        field.imageid + "&name=" + field.imageowner + "''>"+
                        field.imagename + "</a></td><td>" + field.cname +
                             "</td><td>" + field.comment + "</td><td>" + field.time +"</td></tr>";
                    }
                });
                tableComment += "</tbody>"
                document.getElementById("table1").innerHTML = tableComment;
            });
         $(".table-area").show();
    });


        
    $("#download").click(function(){
        let tableDownload = "<thead><tr><td>Image Title</td><td>Image Uploader<td>Time</td></tr></thead><tbody>";
            $.getJSON("http://localhost:3000/download", function(result){
                $.each(result, function(i, field){
                    if(field.downloader === sessionStorage.getItem("name"))
                    {
                        tableDownload+="<tr><td>" + "<a href='../html/preview.html?id=" +
                        field.imageid + "&name=" + field.imageowner + "''>"+ field.imagename +
                        "</a></td><td>" + field.imageowner + "</td><td>" + field.time +
                        "</td></tr>";
                    }
                });
                tableDownload += "</tbody>"
                document.getElementById("table1").innerHTML = tableDownload;
            });
        $(".table-area").show();
    });
        
        
    $("#myposts").click(function(){
        let tablePosts = "<thead><tr><td>Image Title</td><td>Hashtag</td><td>Category</td><td>Time</td></tr></thead><tbody>";
            $.getJSON("http://localhost:3000/pics", function(result){
                $.each(result, function(i, field){
                    if(field.uploader === sessionStorage.getItem("name"))
                    {
                        const pictureId = i+1;
                        tablePosts+="<tr><td>" + "<a href='../html/preview.html?id=" +
                        pictureId + "&name=" + field.uploader + "''>"+
                         field.imagename + "</a></td><td>" + field.hashtag +
                        "</td><td>" + field.category + "</td><td>" + field.time +
                        "</td></tr>";
                    }
                });
                tablePosts += "</tbody>"
                document.getElementById("table1").innerHTML = tablePosts;
            });
        $(".table-area").show();
    });

});