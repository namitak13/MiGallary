$(document).ready(function(){

    $( "#login-button" ).click(function() {

      const username = $("#user").val();
      const password = $("#pass").val();


  $.getJSON("http://localhost:3000/users", function(result){
      let check = 0;
      $.each(result, function(i, field){
          if(field.username === username && field.password === password)
          {
              check = 1;
              sessionStorage.setItem("userid" , field.id);
              sessionStorage.setItem("name" , field.username);
              window.location.href = "homepage.html";
          }
      });

      if(check === 0)
      {
          document.getElementById("loginError").innerHTML="<h3>Invalid username or password</h3>";
      }  
  });
});

});