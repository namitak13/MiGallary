var response;
var date =  new Date();


   

$(document).ready(function(){ 
    
    let urlParams = new URLSearchParams(window.location.search);
    const param = urlParams.get("id");
    const uploader = urlParams.get("name");
    var imagename = "";
    console.log(param);
    console.log(uploader);
    const username = sessionStorage.getItem("name");
    console.log(username);

    //fetching image using image id
    let temp = "";
    $.getJSON("http://localhost:3000/pics", function(result){
                     $.each(result, function(i, field){
                         if(param == field.id)
                         {
                              imagename = field.imagename;
                             console.log(imagename);
                             temp += "<img class='img-card-top' src='"+ field.path + "' alt='alternative'>"+
                             "<div class='card-body'>" +
                         "<h5 class='card-title'>" + field.uploader + "</h5>" +
                         "<p class='card-text'>"+field.imagename+"</p>" +
                         "<p class='card-text'>"+field.hashtag+"</p>"
                         +"</div>";
                         }
                     });
                 console.log(temp);
                 document.getElementById("deck").innerHTML=temp;
             });
            
    //it will fetch comments of image
    let temp2 = "";
     $.getJSON("http://localhost:3000/comment", function(result){
                     $.each(result, function(i, field){
                         if(param == field.imageid)
                         {
                             temp2 +=  field.cname +  "   :   " +
                                       field.comment +  "<br>";
                         }
                     });
                 console.log(temp2);
                 document.getElementById("commentArea").innerHTML=temp2;
             });
             //it will check if image is already liked or not 
             $.getJSON("http://localhost:3000/likes", function(result){
                     $.each(result, function(i, field){
                         if(param == field.imageid && sessionStorage.getItem("name") == field.lname)
                         {  
                             if(field.like == "true")
                             {
                                 console.log(sessionStorage.getItem("name"));
                                 document.getElementById("likeButton").innerHTML = "<i class='far fa-thumbs-up'></i>";
                                 $("#likeButton").css("background-color", "skyblue");
                             }else{
                                 document.getElementById("likeButton").innerHTML = "<i class='far fa-thumbs-up'></i>";
                             }
                         }
                         else{
                             document.getElementById("likeButton").innerHTML = "<i class='far fa-thumbs-up'></i>";
                         }
                     });
             });

//Like functionality
 $("#likeButton").click(function(){   
     $.getJSON("http://localhost:3000/likes", function(result){

        response = result.filter(function(obj){
            return obj.imageid == param && obj.lname == username;
        });

        console.log(response);
         
        if(response.length > 0){
            //toggels the value of like
             $.each(response, function(i, field){
                 var lid =field.id;
                 if(field.like == "true")
                 {
                     console.log(lid);
                     $.ajax({
                         type : "PUT" ,
                         url : "http://localhost:3000/likes/"+lid ,
                         data : 
                         {
                             "imageid" : param ,
                             "imageowner" : uploader ,
                             "imagename" : imagename ,
                             "lname" : sessionStorage.getItem("name"),
                             "time" : new Date(),
                             "like" : "false"
                         } ,
                            
                         success : function(result){
                         console.log(result);
                         alert(JSON.stringify(result));
                         }
                     });
                 }else
                 {
                     $.ajax({
                         type : "PUT" ,
                         url : "http://localhost:3000/likes/"+lid ,
                         data : 
                         {
                             "imageid" : param ,
                             "imageowner" : uploader ,
                             "imagename" : imagename,
                             "lname" : sessionStorage.getItem("name"),
                             "time" : new Date(),
                             "like" : "true"
                         } ,

                         success : function(result){
                             console.log(result);
                             alert(JSON.stringify(result));
                         }
                     });
                 }
             });
         }
         else
         {
             //creating new like record
             $.ajax({
                 type : "POST" ,
                 url : "http://localhost:3000/likes/" ,
                 data : {
                     "imageid" : param ,
                     "imageowner" : uploader ,
                     "imagename" : imagename ,
                     "lname" : sessionStorage.getItem("name"),
                     "time" : new Date(),
                     "like" : "true"
                 } ,
                 success : function(result){
                     console.log(result);
                     alert(JSON.stringify(result));
                 }
             });
         }


      });
 });

 //creating new comment record
 $("#upload").click(function(){
     var comment = $("#comment").val();

     $.ajax({
       type : "POST" ,
       url : "http://localhost:3000/comment" ,
       data : {
           "cname" : sessionStorage.getItem("name") ,
           "imageid" : param ,
           "imageowner" : uploader , 
           "imagename" : imagename ,
           "comment" : comment ,
           "time" : new Date()
       } ,

       success : function(result){
         console.log(result);
         alert(JSON.stringify(result));
       }
     });
   });

   //downloading image
   $("#download").click(function(){
     let temp3 = "";
     $.getJSON("http://localhost:3000/pics", function(result){
                     $.each(result, function(i, field){
                         if(param == field.id)
                         {
                             temp3 += field.path;
                         }
                     });
                 console.log(temp3);
                 var a = document.createElement('a');
                 a.href = temp3;
                 let array = temp3.split("/");
                 console.log(array);
                 let name = array[array.length - 1];
                 console.log(name);
                 a.download = name;
                 document.body.appendChild(a);
                 a.click();
                 document.body.removeChild(a);
     });
     
     //creating download logs
     $.ajax({
       type : "POST" ,
       url : "http://localhost:3000/download" ,
       data : {
           "downloader" : sessionStorage.getItem("name") , 
           "imagename" : imagename ,
           "time" : new Date()
       } ,
       success : function(result){
         console.log(result);
         alert(JSON.stringify(result));
       }
     });
 
 });
});