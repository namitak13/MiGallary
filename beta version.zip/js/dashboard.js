$(document).ready(function () {
     
        //displaying logs of like
        $("#like").click(function(){
            var tableLike = "<thead><tr><td>User</td><td>Image Title</td><td>Time</td></tr></thead><tbody>";
            $.getJSON("http://localhost:3000/likes", function(result){

                console.log(result);
                console.log(sessionStorage.getItem("name"));
                $.each(result, function(i, field){

                    if(field.imageowner == sessionStorage.getItem("name") && field.like == "true")
                    {
                        console.log(tableLike);
                        tableLike+="<tr><td>" + field.lname + "</td><td>" + field.imagename +
                             "</td><td>" + field.time + "</td></tr>";
                        console.log(tableLike);

                    }
                });
                tableLike += "</tbody>"
                document.getElementById("table1").innerHTML = tableLike;
            });
           
        });

        //displaying logs of comment
        $("#comment").click(function(){
            var tableComment = "<thead><tr><td>Image Title</td><td>User</td><td>Comment</td><td>Time</td></tr></thead><tbody>";
            console.log("hello");
            $.getJSON("http://localhost:3000/comment", function(result){

                console.log(result);
                console.log(sessionStorage.getItem("name"));
                $.each(result, function(i, field){

                    if(field.imageowner == sessionStorage.getItem("name"))
                    {
                        console.log(tableComment);
                        tableComment+="<tr><td>" + field.imagename + "</td><td>" + field.cname +
                             "</td><td>" + field.comment + "</td><td>" + field.time +"</td></tr>";
                        console.log(tableComment);

                    }
                });
                tableComment += "</tbody>"
                document.getElementById("table1").innerHTML = tableComment;
            });
            
        });

        //displaying logs of download        
        $("#download").click(function(){
            var tableDownload = "<thead><tr><td>Image Title</td><td>Time</td></tr></thead><tbody>";
            console.log("hello");
            $.getJSON("http://localhost:3000/download", function(result){

                console.log(result);
                console.log(sessionStorage.getItem("name"));
                $.each(result, function(i, field){

                    if(field.downloader == sessionStorage.getItem("name"))
                    {
                        console.log(tableDownload);
                        tableDownload+="<tr><td>" + field.imagename + "</td><td>" + field.time +
                        "</td></tr>";
                        console.log(tableDownload);

                    }
                });
                tableDownload += "</tbody>"
                document.getElementById("table1").innerHTML = tableDownload;
            });
           
        });
        
        //displaying logs of post
        $("#myposts").click(function(){
            var tablePosts = "<thead><tr><td>Image Title</td><td>Hashtag</td><td>Category</td><td>Time</td></tr></thead><tbody>";
            console.log("hello");
            $.getJSON("http://localhost:3000/pics", function(result){

                console.log(result);
                console.log(sessionStorage.getItem("name"));
                $.each(result, function(i, field){

                    if(field.uploader == sessionStorage.getItem("name"))
                    {
                        console.log(tablePosts);
                        tablePosts+="<tr><td>" + field.imagename + "</td><td>" + field.hashtag +
                        "</td><td>" + field.category + "</td><td>" + field.time +
                        "</td></tr>";
                        console.log(tablePosts);

                    }
                });
                tablePosts += "</tbody>"
                document.getElementById("table1").innerHTML = tablePosts;
            });
            
        });
       
    });