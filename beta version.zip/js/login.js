
$(document).ready(function(){

      $( "#login" ).click(function() {

        var username = $("#user").val();
        console.log(username);
        var password = $("#pass").val();
        alert(username + password);


    $.getJSON("http://localhost:3000/users", function(result){
        var check=0;
        $.each(result, function(i, field){
            if(field.username == username && field.password == password)
            {
                alert("Logged in successfully");
                sessionStorage.setItem("userid" , field.id);
                sessionStorage.setItem("name" , field.username);
                check = 1;
                alert(sessionStorage.getItem("userid"));
            }
        });

        if(check == 0)
        {
            alert("Registration required");
        }  
    });
});

});