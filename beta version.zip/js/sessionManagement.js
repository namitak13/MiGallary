//category
function logout(){
    sessionStorage.setItem("userid" , "");
    sessionStorage.setItem("name" , "");
    window.location.href = "homepage.html";
  }
  function navigateLogin(){
    alert("hello");
    window.location.href = "Login.html";
  }

  if (sessionStorage.getItem("userid") != "") {
    document.getElementById("login").style.visibility = "hidden";
    document.getElementById("register").style.visibility = "hidden";
    document.getElementById("profile").style.visibility = "visible";
    var name = sessionStorage.getItem("name");
    document.getElementById("profile").innerHTML = name;
    document.getElementById("logout").style.visibility = "visible";
  }
  else {
    document.getElementById("login").style.visibility = "visible";
    document.getElementById("register").style.visibility = "visible";
    document.getElementById("profile").style.visibility = "hidden";
    document.getElementById("logout").style.visibility = "hidden";
  }

//navigation links
function navigateCat() {
    window.location.href = "category.html";
  }
  function logout() {
    sessionStorage.setItem("userid", "");
    sessionStorage.setItem("name", "");
    window.location.href = "homepage.html";
  }
  
  function navigateLogin() {
    window.location.href = "Login.html";
  }
  
  function navigateRegister() {
    window.location.href = "signup.html";
  }
  
  function navigateDashboard() {
    window.location.href = "dashboard.html";
  }

  //upload image
  $("#upload").click(function () {
    var browseImage = document.getElementById("fileinput").value;
    var browseSplit = browseImage.split("fakepath");
    var name = browseSplit[browseSplit.length - 1];
    var nameFinal = name.substring(1);
    var path = "/assets/images/" + nameFinal;

    var text = $("#textimage").val();

    var select = document.getElementById("category");
    var value = select.options[select.selectedIndex].value;

    var uploader = sessionStorage.getItem("name");
    var uid = sessionStorage.getItem("userid");

    $.ajax({
      type: "POST",
      url: "http://localhost:3000/pics",
      data: {
        "path": path,
        "uploader": uploader,
        "hashtag": text,
        "category": value,
        "uid": uid
      },

      success: function (result) {
        console.log(result);
        alert(JSON.stringify(result));
      }
    });

  });

  //preview
  //redirection to another pages
 function navigateCat(){
    window.location.href="category.html";
  }
  function logout(){
    sessionStorage.setItem("userid" , "");
    sessionStorage.setItem("name" , "");
    window.location.href = "homepage.html";
  }
  function navigateLogin(){
    window.location.href = "Login.html";
  }
  function navigateRegister(){
    window.location.href = "signup.html";
  }

  if(sessionStorage.getItem("userid") != "")
  {
    document.getElementById("login").style.visibility = "hidden";
    document.getElementById("register").style.visibility = "hidden";
    document.getElementById("profile").style.visibility = "visible";
    var name = sessionStorage.getItem("name");
    document.getElementById("profile").innerHTML=name;
    document.getElementById("logout").style.visibility = "visible";
  }
  else{
    document.getElementById("login").style.visibility = "visible";
    document.getElementById("register").style.visibility = "visible";
    document.getElementById("profile").style.visibility = "hidden";
    document.getElementById("logout").style.visibility = "hidden";
  }