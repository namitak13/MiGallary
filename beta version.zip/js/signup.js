$(document).ready(function () {
    var response;
    $("#target").click(function () {

        var fname = $("#fname").val();
        var lname = $("#lname").val();
        var email = $("#email").val();
        var username = $("#uname").val();
        var password = $("#pwd").val();

        $.getJSON("http://localhost:3000/users", function (result) {
           
            response = result.filter(function(obj){
                return obj.username == username;   
            });
           console.log(response);
            if(response.length > 0){
                alert("Username already exist");
            }else{
                $.ajax({
                    type: "POST",
                    url: "http://localhost:3000/users",
                    data: {
                        "firstname": fname,
                        "lastname": lname,
                        "email": email,
                        "username": username,
                        "password": password
                    },
                    success: function (result) {
                        console.log(result);
                        alert(JSON.stringify(result));
                        window.location.href = "Login.html";
                    }
                });
            }
        });
        // console.log(duplicate);
        // if(duplicate == 0){
        //     $.ajax({
        //         type: "POST",
        //         url: "http://localhost:3000/users",
        //         data: {
        //             "firstname": fname,
        //             "lastname": lname,
        //             "email": email,
        //             "username": username,
        //             "password": password
        //         },
    
        //         success: function (result) {
        //             console.log(result);
        //             alert(JSON.stringify(result));
        //             window.location.href = "Login.html";
        //         }
        //     });
        // }

    });
});



