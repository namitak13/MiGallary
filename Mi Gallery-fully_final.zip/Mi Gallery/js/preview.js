$(document).ready(function(){

    var response;

    const urlParams = new URLSearchParams(window.location.search);
    const paramid = urlParams.get("id");
    const uploader = urlParams.get("name");
    var imagename = "";
    const username = sessionStorage.getItem("name");

    $.getJSON("http://localhost:3000/pics", function(result){
        let imageLoad = "";
        $.each(result, function(i, field){
            if(paramid == field.id)
            {
                imagename = field.imagename;
                imageLoad += "<img class='img-card-top' src='"+ field.path + "' alt='alternative'>"+
                            "<div class='card-body'>" +
                            "<h5 class='card-title'>" + field.uploader + "</h5>" +
                            "<p class='card-text'>"+field.imagename+"</p>" +
                            "<p class='card-text'>"+field.hashtag+"</p>"
                            +"</div>";
            }
        });
                  
        document.getElementById("image-card").innerHTML=imageLoad;
    });

    
    $.getJSON("http://localhost:3000/comment", function(result){
        let commentLoad = "<h3>Comments   <i class='far fa-comments'></i></h3>";
        $.each(result, function(i, field){
            if(paramid === field.imageid)
            {
                commentLoad +=  field.cname + "   :   " +
                field.comment +  "<br>";
            }
        });
        document.getElementById("comment-card").innerHTML=commentLoad;
    });

    $.getJSON("http://localhost:3000/likes", function(result){
        $.each(result, function(i, field){
            if(paramid === field.imageid && sessionStorage.getItem("name") === field.lname)
            { 
                if(field.like === "true")
                {
                    document.getElementById("likeButton").innerHTML = "<i class='far fa-thumbs-up'></i>";
                    $("#likeButton").css("background-color", "skyblue");
                }

                else
                {
                    document.getElementById("likeButton").innerHTML = "<i class='far fa-thumbs-up'></i>";
                }
            }
            else
            {
                document.getElementById("likeButton").innerHTML = "<i class='far fa-thumbs-up'></i>";
            }
        });
    });

    $("#likeButton").click(function(){

        if(username != null)
        {
            $.getJSON("http://localhost:3000/likes", function(result){

           response = result.filter(function(obj){
               return obj.imageid === paramid && obj.lname === username;
           });
            
           if(response.length > 0)
           {
               
                $.each(response, function(i, field){
                    var lid =field.id;
                    if(field.like === "true")
                    {
                        $.ajax({
                            type : "PUT" ,
                            url : "http://localhost:3000/likes/"+lid ,
                            data : 
                            {
                                "imageid" : paramid ,
                                "imageowner" : uploader ,
                                "imagename" : imagename ,
                                "lname" : sessionStorage.getItem("name"),
                                "time" : new Date(),
                                "like" : "false"
                            } ,
                               
                            success : function(){
                            }
                        });
                    }

                    else
                    {
                        $.ajax({
                            type : "PUT" ,
                            url : "http://localhost:3000/likes/"+lid ,
                            data : 
                            {
                                "imageid" : paramid ,
                                "imageowner" : uploader ,
                                "imagename" : imagename,
                                "lname" : sessionStorage.getItem("name"),
                                "time" : new Date(),
                                "like" : "true"
                            } ,

                            success : function(){
                            }
                        });
                    }
                });
            }
            else
            {
                $.ajax({
                    type : "POST" ,
                    url : "http://localhost:3000/likes/" ,
                    data : {
                        "imageid" : paramid ,
                        "imageowner" : uploader ,
                        "imagename" : imagename ,
                        "lname" : sessionStorage.getItem("name"),
                        "time" : new Date(),
                        "like" : "true"
                    } ,

                    success : function(){
                    }
                });
            }
         });

        }
        else
        {
            window.location.href = "Login.html";
        }
            
        
    });

    $("#upload-comment").click(function(){
        if(username != null)
        {
            const comment = $("#comment").val();

            $.ajax({
              type : "POST" ,
              url : "http://localhost:3000/comment" ,
              data : {
                  "cname" : sessionStorage.getItem("name") ,
                  "imageid" : paramid ,
                  "imageowner" : uploader , 
                  "imagename" : imagename ,
                  "comment" : comment ,
                  "time" : new Date()
              } ,
    
              success : function(){
              }
            });
        }
        else
        {
            window.location.href = "Login.html";
        }
       
    });

    $("#download").click(function(){
        if(username != null)
        {
            $.getJSON("http://localhost:3000/pics", function(result){
            let picturePath = "";
            $.each(result, function(i, field){
                if(paramid == field.id)
                {
                    picturePath += field.path;
                }
            });
                    
            const a = document.createElement('a');
            a.href = picturePath;
            const array = picturePath.split("/");
            const name = array[array.length - 1];
            a.download = name;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            });

            $.ajax({
            type : "POST" ,
            url : "http://localhost:3000/download" ,
            data : {
              "downloader" : sessionStorage.getItem("name") , 
              "imageid" : paramid ,
              "imageowner" : uploader ,
              "imagename" : imagename ,
              "time" : new Date()
            } ,

            success : function(){
            }
            });
        }

        else
        {
            window.location.href="Login.html";
        }
    });
    
    
});