function navigateCat(){
    window.location.href="category.html";
  }

  function logout(){
    sessionStorage.clear();
    window.location.href = "homepage.html";
  }


  function navigateLogin(){
    window.location.href = "Login.html";
  }

  function navigateRegister(){
    window.location.href = "signup.html";
  }

  function navigateDashboard(){
    window.location.href = "dashboard.html";
  }


  $(document).ready(function(){

    if(sessionStorage.getItem("userid") != null)
    {
      $("#navbar-content").load("/html/navigationbarUser.html");
    }
    else{
      $("#navbar-content").load("/html/navigationbarVisitor.html");
    }

    
  });