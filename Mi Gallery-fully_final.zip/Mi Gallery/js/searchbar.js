$(document).ready(function(){

    $("#search-bar").on("keyup" , function(){
        const value = $(this).val().toLowerCase();
    
            
            $.getJSON("http://localhost:3000/pics", function(result){
                let tempSearch="<div class='row row-cols-1 row-cols-md-3'>";
                    $.each(result, function(i, field){
                        if(field.hashtag.toLowerCase().indexOf(value) > -1)
                        {
    
                        tempSearch += "<div class='col-mb-4 mt-3'>" +  "<a href='../html/preview.html?id=" +
                    field.id + "&name=" + field.uploader + "''>"+
                     "<div class='card h-100 mr-3 ml-3'>" + 
                    "<img class='card-img-top' src='" +field.path+ "' alt='Card image cap'>"+
                    "<div class='card-body'>" +
                    "<h5 class='card-title'>" + field.uploader + "</h5>" +
                    "<p class='card-text'>"+field.imagename+"</p>" +
                    "<p class='card-text'>"+field.hashtag+"</p>"
                    +"</div>" + "</div>" + "</a>" +"</div>" ; ;
                        }
                    });
                document.getElementById("card-area").innerHTML=tempSearch;
            });
    });
});


