$(document).ready(function () {
    var response;
    $("#signup-button").click(function () {

        const fname = $("#fname").val();
        const lname = $("#lname").val();
        const email = $("#email").val();
        const username = $("#uname").val();
        const password = $("#pwd").val();

        $.getJSON("http://localhost:3000/users", function (result) {
           
            response = result.filter(function(obj){
                return obj.username === username;   
            });
            if(response.length > 0){
                document.getElementById("signupError").innerHTML="<h3>Username already exist</h3>";
            }else{
                $.ajax({
                    type: "POST",
                    url: "http://localhost:3000/users",
                    data: {
                        "firstname": fname,
                        "lastname": lname,
                        "email": email,
                        "username": username,
                        "password": password
                    },
                    success: function (){
                        window.location.href = "Login.html";
                    }
                });
            }
        });
    });
});



