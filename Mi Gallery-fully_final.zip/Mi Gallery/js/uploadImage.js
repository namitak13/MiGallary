$(document).ready(function(){

    if(sessionStorage.getItem("name") == null)
    {
        window.location.href = "Login.html";
    }


    $("#upload-button").click(function(){
        const browseImage = document.getElementById("fileinput").value;
        const browseSplit = browseImage.split("fakepath");
        const name = browseSplit[browseSplit.length - 1]; 
        const nameFinal = name.substring(1);
        const path = "/assets/images/"+nameFinal;
      
        const imagename =  $("#nameimage").val();
        const text = $("#textimage").val();
    
        const select = document.getElementById("category");
        const value = select.options[select.selectedIndex].value;
    
        const uploader = sessionStorage.getItem("name");
        const uid = sessionStorage.getItem("userid");
    
        $.ajax({
          type : "POST" ,
          url : "http://localhost:3000/pics" ,
          data : {
              "path" : path ,
              "uploader" : uploader ,
              "imagename" : imagename,
              "hashtag" : text ,
              "category" : value,
              "time" : new Date() ,
              "uid" : uid 
          } ,
    
          success : function(){
              window.location.href = "homepage.html";
          }
        });
    
    
      });


});


